package hello.utilities.enums;

public enum MESSAGETYPE {
    LEAVB,
    NORMAL
}
