package hello.utilities.enums;

public enum GENDER {
    MALE,
    FEMALE
}
