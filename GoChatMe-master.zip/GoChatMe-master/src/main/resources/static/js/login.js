function logowanie(){
    var login = document.getElementById("login").value;
    var pswd = document.getElementById("password").value;
    var jObj;
    var request = new XMLHttpRequest();
    url = "https://localhost:8444/goChatMe/login";
    request.open("POST", url);
	request.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    request.onload = function() {
		
				alert("odpowiedz   "+request.responseText);
        if (this.readyState === 4 && this.status === 200) {
            jObj = JSON.parse(request.responseText);
		
			
            for (var i = 0; i < jObj.length; i++) {
				//jesli jest wiecej niz jeden obiekt iteruj po tablicy
                //przykład jak wyciagnąc wartosci i zapisac je w zmiennej typu Object

					alert(jObj[i]);

             
        
            }
        } else if (this.status === 400) {
            alert("blad serwera/url niepoprawne zapytanie lub parametry");
           
        } else {
            alert("STATUS " + this.status);
            
        }

    }
    request.send("password="+pswd+"&login="+login); 

}